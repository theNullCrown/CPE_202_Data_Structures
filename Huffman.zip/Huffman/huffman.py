# Name: Allie Blaising 


class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char   # stored as an integer - the ASCII character code value
        self.freq = freq   # the frequency count associated with the node
        self.left = None   # Huffman tree (node) to the left
        self.right = None  # Huffman tree (node) to the right

    def __lt__(self, other):
        return comes_before(self, other) # Allows use of Python List sorting

    def set_left(self, node):
        self.left = node

    def set_right(self, node):
        self.right = node



def comes_before(a, b):
    if a.freq == b.freq: # If the frequency of node A is equal to the frequency of node B then we check 
    # if A's ASCII character value is less then B's value 
        return a.char < b.char
    return a.freq < b.freq # Else, we compare the frequency of A and B nodes alone 


def combine(a, b):
    if comes_before(a, b): # Checks to see if B node is greater than A node; If it is then we know that B node will be the 
        # new right child, and A node will be the new left 
        parent = HuffmanNode(min(a.char, b.char), (a.freq + b.freq)) 
        parent.right = b
        parent.left = a
        return parent 
    else: # If B is not greater than A, then we know that B node will be the left node and A will be the greater right node
        parent = HuffmanNode(min(a.char, b.char), (a.freq + b.freq)) 
        parent.right = a
        parent.left = b
        return parent 

"""Creates and returns a new Huffman node with children a and b, with the "lesser node" on the left
The new node's frequency value will be the sum of the a and b frequencies
The new node's char value will be the lesser of the a and b char ASCII values"""

def cnt_freq(filename): 
    counts = [0]*256 # Start by creating an empty python list with 256 entries initialized to zero 
    file_freq = open(filename, "r") # Open file before reading in values 
    for line in file_freq: # Enter double loop to iterate over each single letter  
        for char in line: 
            temp = counts[ord(char)] # Convert each character, into a # that can be used to index to the current position in our list 
            # that is keeping track of the freq of a given character. First, we extract the current frequency count at a location to  
            # ensure that we are adding to the frequency count currently at a given position 
            counts[ord(char)] = temp + 1 # Once, we've extracted the current frequency, we want to iterate the frequency by 1 to 
            # account for the current character we just read in 
    file_freq.close() # Close file 
    return counts # Return python list counts of 256 entries with frequencies corresponding to occurences of characters 


"""Opens a text file with a given file name (passed as a string) and counts the 
    frequency of occurrences of all the characters within that file
    Returns a Python List with 256 entries - counts are initialized to zero.
    The ASCII value of the characters are used to index into this list for the frequency counts"""


"""Create a Huffman tree for characters with non-zero frequency
    Returns the root node of the Huffman tree"""

def create_huff_tree(char_freq):
    huffs = [] # Empty list that we will 
    for char,freq in enumerate(char_freq):
        # For loop w/ enumerate that allows us to keep a number associated with every pass through 
        # the items in char_freq. We do this because the count of the indices we're on translate back to the ASCII character code that 
        # we need to create a new huffman node
        if int(freq) > 0: # If the freq is > 0 then we want to create a huffman node with the frequency and character  
            huffs.append(HuffmanNode(char,freq))
    # After we've iterated through char_freq and created a list of huffman_nodes, we enter a while loop 
    while len(huffs) > 1: 
        huffs.sort() # Start by sorting list (Python will do this using the logic associated with comes_before)
        node0 = huffs.pop(0) # Once the list is sorted, we want to pop the first two items in our sorted list (and this case will be 
        # the lowest two because we've sorted the list)
        node1 = huffs.pop(0) # Pop second 
        huffs.append(combine(node0,node1)) # Combine node1 and node0 according to precedence logic in combine function and append the 
        # resulting parent node  
        # While loop will continue until our length of huffman nodes is 1, in which case we now we've completed all appropriate combinations 
        # and will just have one root parent huffman node 
    return huffs[0]


def create_code(node):
    output_array = ['']*256 # Create an array of 256 empty character strings 
    if node is not None: 
        return create_code_helper(node, '', output_array) # Call recursive function 
    return 


def create_code_helper(node, current_string, output_array): 
    if node.left == None and node.right == None: # Base case indicating that we can traverse back up to the head/root node 
        output_array[node.char] = current_string
    else: 
        if node.left != None: # If there is a left node to traverse, then we add 0 to current string 
            new_string = current_string + "0"
        # Next, we push node.left in and new string with added 0, to our recursive function 
            create_code_helper(node.left, new_string, output_array)
        if node.right != None: # If there is a right node to traverse, then we add 0 to current string 
            new_string = current_string + "1" 
            # Next, we push node.right in and new string with added 1, to our recursive function 
            create_code_helper(node.right, new_string, output_array) 
    return output_array

## Edge cases: 
# ─ If the input file consists of only one unique character, say "aaaaa", it should write just that
# character ASCII value followed by a space followed by the number of occurrences: “97 5”
# ─ In case of an empty input text file, your program should also produce an empty file. (DONE)
# ─ If an input file does not exist, your program should raise a FileNotFoundError.


def huffman_encode(in_file, out_file): 
    freq_list = cnt_freq(in_file) # Call count_freq that we are going to feed into create_header
    empty = True 
    for index in freq_list: 
        if index != 0: 
            empty = False 
    out_file = open(out_file, "w")
    if not empty: 
        output = create_header(freq_list) # Create output from create_header 
        huff_tree = create_huff_tree(freq_list) # Create a huffman tree with frequency_list 
        output_code = create_code(huff_tree) # Output array that we will use to index in double loop below
        out_file.write(output + "\n") # Write header 
        try: 
            in_file = open(in_file, "r") # Open in_file and prepare to extract code from array based on the ord(char)
        except FileNotFoundError as error:
            raise FileNotFoundError # value that will index into the location w/ the correct code to extract from output_code
        test_string = ''
        for line in in_file: 
            for char in line: 
                temp = output_code[ord(char)] # Use the ord(char) value to index into output_code
                test_string += str(temp) 
        "".join(test_string) # Format like solution file 
        out_file.write(str(test_string)) # Write second and final line to file # Close all files 
        in_file.close()
    elif empty: 
        out_file.write(" ")
    out_file.close() 


def create_header(freq_list): 
    new_string = ''
    for char,freq in enumerate(freq_list): # For loop w/ enumerate that allows us to keep a number associated with every pass through 
        # the items in char_freq. We do this because the count of the indices we're on translate back to the ASCII character code that 
        # we need to create a new huffman node
        if freq > 0:
            new_string += str(char) + ' ' + str(freq) + ' ' # Separate char and freq with spaces 
    return new_string.rstrip() # Strip excess white space from the end of header 

'''
def create_header(freq_list): 
    new_string = ''
    freq_counter = 0 
    for char,freq in enumerate(freq_list): # For loop w/ enumerate that allows us to keep a number associated with every pass through 
        # the items in char_freq. We do this because the count of the indices we're on translate back to the ASCII character code that 
        # we need to create a new huffman node
        freq_counter += 1 
        if freq > 0 and freq_counter > 1: 
            new_string += str(char) + ' ' + str(freq) + ' ' # Separate char and freq with spaces 
        elif freq_counter == 1: 
            new_string += ''
    return new_string.rstrip() # Strip excess white space from the end of header 
'''

